package dbcs;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public class Mainline extends Application {
	
	public final static double WINDOW_WIDTH = 700;
	public final static double WINDOW_HEIGHT = 550;
	public final static double WINDOW_WIDTH2 = 980;


	
	@Override
	public void start(Stage theStage) throws Exception {
		theStage.setTitle("ProjectDBMS");												// Label the stage (a window)
		Pane theRoot = new Pane();														// Create a pane within the window
		new UserInterface(theRoot);
		Scene theScene = new Scene(theRoot, WINDOW_WIDTH2, WINDOW_HEIGHT);				// Create the scene
		theStage.setScene(theScene);													// Set the scene on the stage
		theStage.show();
	
	}
		public static void main(String[] args) {										// This method may not be required
		launch(args);																	// for all JavaFX applications using
	}																					// other IDEs.
}
